package pregraph;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;

import pregraph.Kmer32;
import pregraph.Kmer64;

public class Query64 {
	
	private int pivotLen;
	private int numOfBlocks;
	private int bufSize;
	
	private boolean flag;
	
	private static int[] valTable = new int[]{0,-1,1,-1,-1,-1,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3};
	private static char[] twinTable = new char[]{'T','0','G','0','0','0','C','0','0','0','0','0','0','0','0','0','0','0','0','A'};
	
	public Query64(int pivotLen, int numOfBlocks, int bufSize){
		this.pivotLen = pivotLen;
		this.numOfBlocks = numOfBlocks;
		this.bufSize = bufSize;
	}
	
	private int strcmp(char[] a, char[] b, int froma, int fromb, int len){
		for(int i = 0; i < len; i++){
			if(a[froma+i] < b[fromb+i])
				return -1;
			else if(a[froma+i] > b[fromb+i])
				return 1;
		}
		return 0;
	}
	
	private int findSmallest(char[] a){
		
		int min_pos = 0;
		
		int len = a.length;
		
		for(int i=1; i<=len-pivotLen; i++){
			if(strcmp(a, a, min_pos, i, pivotLen)>0)
				min_pos = i;
		}
		
		return min_pos;
	}
	
	private int calPosNew(char[] a, int from, int to){
		
		int val=0;
		
		for(int i=from; i<to; i++){
			val = val<<2;
			val += valTable[a[i]-'A'];
		}
		
		return val % numOfBlocks;
	}

	private int findLocation(char[] a, char[] b){
		
		int pos1 = findSmallest(a);
		int pos2 = findSmallest(b);
		
		if(strcmp(a,b,pos1,pos2,pivotLen)<0){
			flag = true;
			return calPosNew(a,pos1,pos1+pivotLen);
		}
		else{
			flag = false;
			return calPosNew(b,pos2,pos2+pivotLen);
		}	
	}
	
	public int QueryFreq(char[] kmerStr) throws Exception{
		
		int len = kmerStr.length;
		
		char[] revKmerStr = new char[len];
		
		for(int i=0; i<len; i++){
			revKmerStr[i] = twinTable[kmerStr[len-1-i]-'A'];
		}
		
		int pos = findLocation(kmerStr, revKmerStr);
		
		System.out.println("Partition ID: " + pos);
		
		if(len>32){
			Kmer64 forward = new Kmer64(kmerStr, false);
			Kmer64 backward = new Kmer64(revKmerStr, false);
			Kmer64 kmerQuery;
			
			if(Kmer64.KmerSmaller(forward, backward))
				kmerQuery = forward;
			else
				kmerQuery = backward;
			
			//System.out.println("kmer: " + kmerQuery.high + "\t" + kmerQuery.low);
			
			long high, low;

			int count;
			
			DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(new File("Count/counts"+pos)), bufSize));
			
			while(true){
				try{
					high = in.readLong();
				}catch(EOFException e){
					break;
				}
				
				low = in.readLong();
				
				count = in.readInt();
				
				if(((high == kmerQuery.high) && (low == kmerQuery.low))){
					in.close();
					return count;
				}			
			}
			
			in.close();
		}
		
		else{
			Kmer32 forward = new Kmer32(kmerStr, false);
			Kmer32 backward = new Kmer32(revKmerStr, false);
			Kmer32 kmerQuery;
			
			if(Kmer32.KmerSmaller(forward, backward))
				kmerQuery = forward;
			else
				kmerQuery = backward;
			
			//System.out.println("kmer: " + kmerQuery.high + "\t" + kmerQuery.low);
			
			long low;

			int count;
			
			DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(new File("Count/counts"+pos)), bufSize));
			
			while(true){
				try{
					low = in.readLong();
				}catch(EOFException e){
					break;
				}
				
				count = in.readInt();
				
				if(low == kmerQuery.low){
					in.close();
					return count;

				}			
			}
			
			in.close();
		}
		
		
		return 0;		
	}
	
	public static void main(String[] args){
    	
    	int numBlocks = 256, bufferSize = 8192, pivotLen = 6;
    	String queryKmer = null;
    	
    	if(args[0].equals("-help")){
    		System.out.print("Usage: java -jar Query64.jar -q queryKmer -NB numOfBlocks -p pivotLen [options]\n" +
	        			       "Options Available: \n" + 
	        			       "[-b bufferSize] : (Integer) Read/Writer Buffer Size. Default: 8192" + "\n");
    		return;
    	}
    	
    	for(int i=0; i<args.length; i+=2){
    		if(args[i].equals("-q"))
    			queryKmer = args[i+1];
    		else if(args[i].equals("-NB"))
    			numBlocks = new Integer(args[i+1]);
    		else if(args[i].equals("-p"))
    			pivotLen = new Integer(args[i+1]);
    		else if(args[i].equals("-b"))
    			bufferSize = new Integer(args[i+1]);
    		else{
    			System.out.println("Wrong with arguments. Abort!");
    			return;
    		}
    	}
    	
		
		Query64 bdgraph = new Query64(pivotLen, numBlocks, bufferSize);
	
		try{
			System.out.println("Program Configuration:");
	    	System.out.print("Pivot Length: " + pivotLen + "\n" +
	    					 "# Of Blocks: " + numBlocks + "\n" +
	    					 "Query Kmer: " + queryKmer + "\n" +
	    					 "R/W Buffer Size: " + bufferSize + "\n");
		
			int freq = bdgraph.QueryFreq(queryKmer.toCharArray());	
			
			System.out.println("The frequency of kmer " + queryKmer + " is: " + freq);
			
			
		}
		catch(Exception E){
			System.out.println("Exception caught!");
			E.printStackTrace();
		}
		
	}	
	
	
	
	

}
