package pregraph;

import java.io.*;


public class Stat64 {
	
	private int k;
	private int numOfBlocks;
	private int bufSize;
	private int maxArraySize;
	private int[] stat;
	
	private int blockID;

	public Stat64(int kk, int numberOfBlocks, int bufferSize, int maxArraySize){
		this.k = kk;
		this.numOfBlocks = numberOfBlocks;
		this.bufSize = bufferSize;
		this.blockID = 0;
		this.maxArraySize = maxArraySize;
		this.stat = new int[this.maxArraySize+1];
	}
	
	public void stats(){
		
		FileWriter fw_stat = null;
		BufferedWriter bfw_stat = null;
		DataInputStream in = null;
		
		int p;
		
		int count;
		
		long high, low;
		
		
		try{
			fw_stat = new FileWriter("stat.txt");
			bfw_stat = new BufferedWriter(fw_stat, bufSize);
		
			while(blockID<numOfBlocks){
				
				p = blockID;
				blockID++;
				
				in = new DataInputStream(new BufferedInputStream(new FileInputStream(new File("Count/counts"+p)), bufSize));
				
				if(k > 32){
					while(true){
						try{
							high = in.readLong();
						}catch(EOFException e){
							break;
						}
						
						low = in.readLong();
						
						count = in.readInt();
						
						stat[count<maxArraySize?count:maxArraySize]++;
						
					}
				}
				
				else{
					while(true){
						try{
							low = in.readLong();
						}catch(EOFException e){
							break;
						}
						
						count = in.readInt();
						
						stat[count<maxArraySize?count:maxArraySize]++;
					}
				}
				
				in.close();
				
			}
			
			for(int i=1;i<=maxArraySize;i++){
				bfw_stat.write(stat[i]+"\n");
			}
			
			bfw_stat.close();
			fw_stat.close();
						
		}catch(Exception E){
			System.out.println("Exception caught!");
			E.printStackTrace();
		}
	}
	
	public void Run() throws Exception{
		long time1=0;
		
		long t1 = System.currentTimeMillis();
		System.out.println("Stats Begin!");	
		stats();
		long t2 = System.currentTimeMillis();
		time1 = (t2-t1)/1000;
		System.out.println("Time used for getting statistics: " + time1 + " seconds!");
		
	}
	
	public static void main(String[] args){
    	
    	int k = 15, numBlocks = 256, bufferSize = 8192, maxArraySize = 256;
    	
    	if(args[0].equals("-help")){
    		System.out.print("Usage: java -jar Stat64.jar -k k -NB numOfBlocks [options]\n" +
	        			       "Options Available: \n" + 
	        			       "[-m maxArraySize] : (Integer) Max Number of Counts to Be Considered. Default: 256" + "\n" +
	        			       "[-b bufferSize] : (Integer) Read/Writer Buffer Size. Default: 8192" + "\n");
    		return;
    	}
    	
    	for(int i=0; i<args.length; i+=2){
    		if(args[i].equals("-k"))
    			k = new Integer(args[i+1]);
    		else if(args[i].equals("-NB"))
    			numBlocks = new Integer(args[i+1]);
    		else if(args[i].equals("-m"))
    			maxArraySize = new Integer(args[i+1]);
    		else if(args[i].equals("-b"))
    			bufferSize = new Integer(args[i+1]);
    		else{
    			System.out.println("Wrong with arguments. Abort!");
    			return;
    		}
    	}
    	
		
		Stat64 bdgraph = new Stat64(k, numBlocks, bufferSize, maxArraySize);
	
		try{
			System.out.println("Program Configuration:");
	    	System.out.print("Kmer Length: " + k + "\n" +
	    					 "# Of Blocks: " + numBlocks + "\n" +
	    					 "Max Array Size: " + maxArraySize + "\n" +
	    					 "R/W Buffer Size: " + bufferSize + "\n");
		
			bdgraph.Run();	
			
		}
		catch(Exception E){
			System.out.println("Exception caught!");
			E.printStackTrace();
		}
		
	}	
	

}
