package pregraph;

import java.io.*;
import java.util.concurrent.CountDownLatch;


public class Dump64 {
	
	private int k;
	private int numOfBlocks;
	private int bufSize;
	
	private Object lock_blocks = new Object();
	
	private int blockID;

	public Dump64(int kk, int numberOfBlocks, int bufferSize){
		this.k = kk;
		this.numOfBlocks = numberOfBlocks;
		this.bufSize = bufferSize;
		this.blockID = 0;
	}
	
	public class MyThreadDump extends Thread{
		private CountDownLatch threadsSignal;
		
		public MyThreadDump(CountDownLatch threadsSignal){
			super();
			this.threadsSignal = threadsSignal; 
		}
		
		@Override
		public void run(){
			System.out.println(Thread.currentThread().getName() + "Start..."); 
			
			FileWriter fw = null;
			BufferedWriter bfw = null;
			DataInputStream in = null;
			
			int p;
			
			long high, low;
			int count;
			
			
			try{
				File dir = new File("CountDump");
				if(!dir.exists())
					dir.mkdir();
				
				while(blockID<numOfBlocks){
					
					synchronized (lock_blocks){
						p = blockID;
						blockID++;
					}
					
					fw = new FileWriter("CountDump/dumps"+p);
					bfw = new BufferedWriter(fw, bufSize);
					
					in = new DataInputStream(new BufferedInputStream(new FileInputStream(new File("Count/counts"+p)), bufSize));
					
					if(k > 32){
						while(true){
							try{
								high = in.readLong();
							}catch(EOFException e){
								break;
							}
							
							low = in.readLong();
							
							count = in.readInt();
							
							bfw.write(new Kmer64(low,high).toDNAStr(k) + "\t" + count + "\n");
							
						}
					}
					
					else{
						while(true){
							try{
								low = in.readLong();
							}catch(EOFException e){
								break;
							}
							
							high = 0;
							
							count = in.readInt();
							
							bfw.write(new Kmer64(low,high).toDNAStr(k) + "\t" + count + "\n");
						}
					}
					

					bfw.close();
					fw.close();
						
					in.close();
					
				}
							
			}catch(Exception E){
				System.out.println("Exception caught!");
				E.printStackTrace();
			}
			
			threadsSignal.countDown();  
			System.out.println(Thread.currentThread().getName() + "End. Remaining" + threadsSignal.getCount() + " threads");  
			
		}
	}
	
	public void Dump(int threadNum) throws Exception{
		
		CountDownLatch threadSignal = new CountDownLatch(threadNum);
		
		for(int i=0;i<threadNum;i++){
			Thread t = new MyThreadDump(threadSignal);
			t.start();
		}
		threadSignal.await();
		System.out.println(Thread.currentThread().getName() + "End."); 
		
	}
	
	public void Run(int numThreads) throws Exception{
		long time1=0;
		
		long t1 = System.currentTimeMillis();
		System.out.println("Dump Begin!");	
		Dump(numThreads);
		long t2 = System.currentTimeMillis();
		time1 = (t2-t1)/1000;
		System.out.println("Time used for dumping: " + time1 + " seconds!");
		
	}
	
	public static void main(String[] args){
    	
    	int k = 15, numBlocks = 256, numThreads = 8, bufferSize = 8192;
    	
    	if(args[0].equals("-help")){
    		System.out.print("Usage: java -jar Dump64.jar -k k -NB numOfBlocks [options]\n" +
	        			       "Options Available: \n" + 
	        			       "[-t numOfThreads] : (Integer) Number Of Threads. Default: 8" + "\n" +
	        			       "[-b bufferSize] : (Integer) Read/Writer Buffer Size. Default: 8192" + "\n");
    		return;
    	}
    	
    	for(int i=0; i<args.length; i+=2){
    		if(args[i].equals("-k"))
    			k = new Integer(args[i+1]);
    		else if(args[i].equals("-NB"))
    			numBlocks = new Integer(args[i+1]);
    		else if(args[i].equals("-t"))
    			numThreads = new Integer(args[i+1]);
    		else if(args[i].equals("-b"))
    			bufferSize = new Integer(args[i+1]);
    		else{
    			System.out.println("Wrong with arguments. Abort!");
    			return;
    		}
    	}
    	
		
		Dump64 bdgraph = new Dump64(k, numBlocks, bufferSize);
	
		try{
			System.out.println("Program Configuration:");
	    	System.out.print("Kmer Length: " + k + "\n" +
	    					 "# Of Blocks: " + numBlocks + "\n" +
	    					 "# Of Threads: " + numThreads + "\n" +
	    					 "R/W Buffer Size: " + bufferSize + "\n");
		
			bdgraph.Run(numThreads);	
			
		}
		catch(Exception E){
			System.out.println("Exception caught!");
			E.printStackTrace();
		}
		
	}	
	

}
