package pregraph;

public class Kmer32 extends Object{
	
	public long low;
	
	private final static char[] baseDic = {'A','C','G','T'};
	private final static int[] intDic = {0,-1,1,-1,-1,-1,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3};  
	
	private final int base2int(char base){
		return intDic[base-'A'];
	}
	
	private final char int2base(int intv){
		return baseDic[intv];
	}
	
	public Kmer32(char[] str, boolean rev){
		
		this.low = 0;
		
		int len = str.length;
		
		if(!rev){
			for(int i=0; i<=len-1; i++){
				this.low = (this.low<<2) + base2int(str[i]);
			}	
		}
		else{
			for(int i=len-1; i>=0; i--){
				this.low = (this.low<<2) + 3^base2int(str[i]);
			}
		}
		
	}
	
	public Kmer32(char[] str, int start, int end, boolean rev){
		
		this.low = 0;
		
		if(!rev){	
			for(int i=start; i<=end-1; i++){
				this.low = (this.low<<2) + base2int(str[i]);
			}			
		}
		else{
			for(int i=end-1; i>=0; i--){
				this.low = (this.low<<2) + 3^base2int(str[i]);
			}
		}
		
	}
	
	public Kmer32(long low){
		this.low = low;
	}
	
	@Override
	public boolean equals(Object another){
		Kmer32 k = (Kmer32)another;
		if(this.low == k.low)
			return true;
		else
			return false;
	}
	
	@Override
	public int hashCode(){
		return (int)((low^(low>>>32)));
	}	
	
	public static boolean KmerSmaller(Kmer32 kmer1, Kmer32 kmer2)
	{	
		if ( kmer1.low < kmer2.low )
			return true;
		else
			return false; 
	}
	
	
	public static void main(String[] args){
		
			
	}

}
