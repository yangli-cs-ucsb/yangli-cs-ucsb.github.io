package pregraph;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.CountDownLatch;

import pregraph.Kmer32;

public class Count32{
	
	private int k;
	private int numOfBlocks;
	private int bufSize;
	
	private Object lock_blocks = new Object();
	private Object lock2 = new Object();
	
	private int capacity;
	
	private int blockID;
	
	private long forAndVal32;
	
	private long totalNumNodes = 0;
	
	private static int[] valTable = new int[]{0,-1,1,-1,-1,-1,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3};

	public Count32(int kk, int numberOfBlocks, int bufferSize, int HScapacity){
		this.k = kk;
		this.numOfBlocks = numberOfBlocks;
		this.bufSize = bufferSize;
		this.capacity = HScapacity;
		this.blockID = 0;
		this.forAndVal32 = (long)Math.pow(2, 2*k) - 1;
	}
	
	public class MyThread extends Thread{
		private CountDownLatch threadsSignal;
		
		public MyThread(CountDownLatch threadsSignal){
			super();
			this.threadsSignal = threadsSignal; 
		}
		
		@Override
		public void run(){
			System.out.println(Thread.currentThread().getName() + "Start..."); 
			
			FileReader fr;
			BufferedReader bfr;
			DataOutputStream out = null;
			HashMap<Kmer32,Integer> nodes = new HashMap<Kmer32,Integer>(capacity);
			
			String line;
			
			int p,j;
			Kmer32 k1, k1_rev;
			
			
			try{
				File dir = new File("Count");
				if(!dir.exists())
					dir.mkdir();
				
				nodes.clear();
				
				while(blockID<numOfBlocks){
					
					synchronized (lock_blocks){
						p = blockID;
						blockID++;
					}
					
					fr = new FileReader("Nodes/nodes"+p);
					bfr = new BufferedReader(fr, bufSize);
					
					out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File("Count/counts"+p)), bufSize));
					
					while((line = bfr.readLine()) != null){	
						
						char[] lineCharArray = line.toCharArray();
						
						k1 = new Kmer32(lineCharArray,0,k,false);
						k1_rev = new Kmer32(lineCharArray,0,k,true);
						
						int bound = lineCharArray.length - k + 1;
						
						for(j = 0; j < bound; j++){
				
							if(j != 0){
								
								k1 = new Kmer32(((k1.low<<2) + valTable[lineCharArray[k+j-1]-'A']) & forAndVal32);
								k1_rev = new Kmer32((k1_rev.low>>>2) + ((long)((valTable[lineCharArray[k+j-1]-'A']^3))<<((k-1)<<1)));
									
							}
							
							Kmer32 k = Kmer32.KmerSmaller(k1, k1_rev)?k1:k1_rev;
							
							Integer cnt = nodes.get(k);
							
							if(cnt == null){
								nodes.put(k, 1);	
							}
							else{
								nodes.put(k, cnt+1);
							}
							
						}
					}
					
					Iterator<Entry<Kmer32, Integer>> iter = nodes.entrySet().iterator(); 
					while (iter.hasNext()) { 
					     Entry<Kmer32, Integer> entry = (Entry<Kmer32, Integer>) iter.next();  
					     
					     out.writeLong(entry.getKey().low);
					     out.writeInt(entry.getValue());
					}
					
					synchronized(lock2){
						totalNumNodes+=nodes.size();
					}
					
					nodes.clear();
				
					out.close();
						
					bfr.close();
					fr.close();	
					
				}
							
			}catch(Exception E){
				System.out.println("Exception caught!");
				E.printStackTrace();
			}
			
			threadsSignal.countDown();  
			System.out.println(Thread.currentThread().getName() + "End. Remaining" + threadsSignal.getCount() + " threads");  
			
		}
	}
	
	private void BuildMap(int threadNum) throws Exception{
		CountDownLatch threadSignal = new CountDownLatch(threadNum);
		
		for(int i=0;i<threadNum;i++){
			Thread t = new MyThread(threadSignal);
			t.start();
		}
		threadSignal.await();
		System.out.println(Thread.currentThread().getName() + "End."); 
	}
	
	private void OutputStat() throws Exception{
		
		System.out.println("Total num of nodes: "+totalNumNodes);
	}
	
	public void Run(int numThreads) throws Exception{
		long time1=0;
		
		long t1 = System.currentTimeMillis();
		System.out.println("Count Kmers Begin!");	
		BuildMap(numThreads);	
		OutputStat();
		long t2 = System.currentTimeMillis();
		time1 = (t2-t1)/1000;
		System.out.println("Time used for counting kmers: " + time1 + " seconds!");
		
	}
	
	public static void main(String[] args){
    	
    	int k = 15, numBlocks = 256, numThreads = 8, bufferSize = 8192, hsmapCapacity = 1000000;
    	
    	if(args[0].equals("-help")){
    		System.out.print("Usage: java -jar Count32.jar -k k -NB numOfBlocks [options]\n" +
	        			       "Options Available: \n" + 
	        			       "[-t numOfThreads] : (Integer) Number Of Threads. Default: 8" + "\n" +
	        			       "[-b bufferSize] : (Integer) Read/Writer Buffer Size. Default: 8192" + "\n" +
	        			       "[-c capacity] : (Integer) Hashmap Capacity. Default: 1000000" + "\n");
    		return;
    	}
    	
    	for(int i=0; i<args.length; i+=2){
    		if(args[i].equals("-k"))
    			k = new Integer(args[i+1]);
    		else if(args[i].equals("-NB"))
    			numBlocks = new Integer(args[i+1]);
    		else if(args[i].equals("-t"))
    			numThreads = new Integer(args[i+1]);
    		else if(args[i].equals("-b"))
    			bufferSize = new Integer(args[i+1]);
    		else if(args[i].equals("-c"))
    			hsmapCapacity = new Integer(args[i+1]);
    		else{
    			System.out.println("Wrong with arguments. Abort!");
    			return;
    		}
    	}
    	
		
		Count32 bdgraph = new Count32(k, numBlocks, bufferSize, hsmapCapacity);
	
		try{
			System.out.println("Program Configuration:");
	    	System.out.print("Kmer Length: " + k + "\n" +
	    					 "# Of Blocks: " + numBlocks + "\n" +
	    					 "# Of Threads: " + numThreads + "\n" +
	    					 "R/W Buffer Size: " + bufferSize + "\n" +
	    					 "Hashmap Capacity: " + hsmapCapacity + "\n");
		
			bdgraph.Run(numThreads);	
			
		}
		catch(Exception E){
			System.out.println("Exception caught!");
			E.printStackTrace();
		}
		
	}	
	
	
}